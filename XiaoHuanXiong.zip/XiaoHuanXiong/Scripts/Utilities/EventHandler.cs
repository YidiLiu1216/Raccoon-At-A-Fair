﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace XiaoHuanXiong.Common
{
    public static class EventHandler
    {
        // format
        /*public static event Action<int, Vector3> InstantiateItemInScene;
        public static void CallInstantiateItemInScene(int itemID, Vector3 position)
        {
            InstantiateItemInScene?.Invoke(itemID, position);
        }*/

    }
}

