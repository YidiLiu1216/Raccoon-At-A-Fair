using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XiaoHuanXiong.Common;

namespace XiaoHuanXiong.Game
{
    public class ResourceItemManager : Singleton<ResourceItemManager>
    {
        public List<GameObject> resources;

    }
}

